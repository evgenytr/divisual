# CakeIntl plugin for CakePHP

## Installation

You can install this plugin into your CakePHP application using [composer](http://getcomposer.org).

The recommended way to install composer packages is:

```
composer require hraq/cake-intl dev-master --ignore-platform-reqs
```

Add:

```
Plugin::load('CakeIntl', ['bootstrap' => true]);
```

in "config/bootstrap.php"


## Notes

THIS PLUGIN DOESN'T CONTAIN ANY FUNCTIONALITY.

If you need any real functionality from Intl, please install "php_intl".

IMPORTANT: Every time you use install or update in composer, you need put "--ignore-platform-reqs" also in command

Thank you :)
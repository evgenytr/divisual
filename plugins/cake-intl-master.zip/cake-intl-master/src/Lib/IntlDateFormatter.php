<?php

class IntlDateFormatter
{
    const SHORT  = 1;
    const MEDIUM = 2;
}
